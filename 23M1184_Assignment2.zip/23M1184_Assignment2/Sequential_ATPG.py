class Circuit:
    def __init__(self, gates, primary_inputs, primary_outputs):
        self.gates = gates  # List of gate dictionaries
        self.net_values = {}  # Dictionary to store the value of each net
        self.pis = primary_inputs  # Set of primary input nets
        self.pos = primary_outputs  # Set of primary output nets
 
        # Initialize all net values to 'x' (unknown).
        for gate in gates:
            self.net_values[gate['output']] = 'x'
            for net in gate['inputs']:
                if net not in self.net_values:
                    self.net_values[net] = 'x'
        for pi in primary_inputs:
            self.net_values[pi] = 'x'
        for po in primary_outputs:
            if po not in self.net_values:
                self.net_values[po] = 'x'
    
    def store_primary_outputs(self):
        """
        Stores the current values of primary outputs in the 'stored_outputs' variable.
        """
        self.stored_outputs = self.get_outputs().copy()
        print(f"Stored primary output values: {self.stored_outputs}")
    def get_stored_outputs(self):
        """
        Returns the stored primary output values.
        """
        return self.stored_outputs
    def get_net_value(self, net):
        return self.net_values.get(net, 'x')
 
    def set_net_value(self, net, value):
        self.net_values[net] = value
 
    def get_outputs(self):
        return {po: self.net_values[po] for po in self.pos}
 
    def get_pi_values(self):
        return {pi: self.net_values[pi] for pi in self.pis}
 
    def __str__(self):
        # Create a summary of the circuit's state
        result = "Circuit State:\n"
        result += "Gates:\n"
        for gate in self.gates:
            result += f"  {gate['name']}: {gate['type']} with inputs {gate['inputs']} and output {gate['output']}\n"
        result += "\nNet Values:\n"
        for net, value in self.net_values.items():
            result += f"  {net}: {value}\n"
        result += "\nPrimary Inputs:\n  " + ", ".join(self.pis) + "\n"
        result += "Primary Outputs:\n  " + ", ".join(self.pos) + "\n"
        return result
   
    def print_state(self):
        """
        Prints the current state of the circuit, including net values,
        primary inputs, and primary outputs.
        """
        print("Circuit State:")
        print("Net Values:")
        for net, value in self.net_values.items():
            print(f"  {net}: {value}")
        print("Primary Inputs:")
        for pi in self.pis:
            print(f"  {pi}: {self.net_values[pi]}")
        print("Primary Outputs:")
        for po in self.pos:
            print(f"  {po}: {self.net_values[po]}")
        print()
 
 
def evaluate_gate(gate_type, inputs):
    if gate_type == 'AND':
        if '0' in inputs:
            return '0'
        elif 'x' in inputs:
            return 'x'
        elif 'D' in inputs and 'D_bar' in inputs:
            return '0'
        elif 'D' in inputs:
            return 'D'
        elif 'D_bar' in inputs:
            return 'D_bar'
        else:
            return '1'
    elif gate_type == 'OR':
        if '1' in inputs:
            return '1'
        elif 'x' in inputs:
            return 'x'
        elif 'D' in inputs and 'D_bar' in inputs:
            return '1'
        elif 'D' in inputs:
            return 'D'
        elif 'D_bar' in inputs:
            return 'D_bar'
        else:
            return '0'
    elif gate_type == 'XOR':
        if 'x' in inputs:
            return 'x'
       
        # XOR logic: same inputs yield '0', different inputs yield '1'
        a, b = inputs
 
        # Special case handling for D and D_bar.
        if a == b:
            return '0'  # Same values (including D, D_bar pairs) give 0.
        if (a == 'D' and b == '1') or (a == '1' and b == 'D'):
            return 'D_bar'
        if (a == 'D_bar' and b == '1') or (a == '1' and b == 'D_bar'):
            return 'D'
       
        # For '0' and '1', and normal XOR behavior.
        return '1' if a != b else '0'
   
    elif gate_type == 'NOT':
        assert len(inputs) == 1, "NOT gate must have exactly one input."
        if inputs[0] == '0':
            return '1'
        elif inputs[0] == '1':
            return '0'
        elif inputs[0] == 'D':
            return 'D_bar'
        elif inputs[0] == 'D_bar':
            return 'D'
        else:
            return 'x'
    else:
        raise ValueError(f"Unsupported gate type: {gate_type}")
 
 
def forward_implication(circuit):
    stable = False
    while not stable:
        stable = True
        for gate in circuit.gates:
            input_values = [circuit.get_net_value(net) for net in gate['inputs']]
            output_value = evaluate_gate(gate['type'], input_values)
            # print(f"gate type {gate['type']} and inputs {input_values}")
            if circuit.get_net_value(gate['output']) != output_value:
                circuit.set_net_value(gate['output'], output_value)
                stable = False
    print("state after fi:")
    circuit.print_state()
 
def inject_fault(circuit, fault):
    net, stuck_value = fault
    circuit.set_net_value(net, stuck_value)
    print(f"Injecting fault: {net} stuck-at-{stuck_value}")
    print(f"Circuit after inject_fault {circuit}")
 
 
def select_gate_from_d_frontier(circuit):
    for gate in circuit.gates:
        input_values = [circuit.get_net_value(net) for net in gate['inputs']]
        # print(f"input values are: {input_values}")
        if 'D' in input_values or 'D_bar' in input_values:
            output_value = circuit.get_net_value(gate['output'])
            if output_value == 'x':
                return gate
    return None
 
 
def select_unassigned_input(gate, circuit):
    for input_net in gate['inputs']:
        if circuit.get_net_value(input_net) == 'x':
            return input_net
    return None
 
 
def get_non_controlling_value(gate):
    if gate['type'] == 'AND':
        return '1'
    elif gate['type'] == 'OR':
        return '0'
    else:
        raise ValueError("Unsupported gate type.")
 
 
def set_objective(fault, circuit):
    fault_net, stuck_value = fault
    print("set_objective is called")
    # Attempt to activate the fault by driving the net to the opposite of its stuck-at value.
    desired_value = '1' if stuck_value == '0' else '0'
    print(f"Setting objective to activate fault at {fault_net} by driving it to {desired_value}")
 
    # Check if the net is not yet driven to this desired value.
    if circuit.get_net_value(fault_net) != desired_value:
        return fault_net, desired_value
 
    # If the fault is already activated, proceed to propagation.
    gate = select_gate_from_d_frontier(circuit)
    print(f"Selected gate from D-frontier: {gate}")
 
    if gate:
        unassigned_input = select_unassigned_input(gate, circuit)
        non_controlling_value = get_non_controlling_value(gate)
        print(f"Setting objective to propagate fault through gate {gate['name']} by setting input {unassigned_input} to {non_controlling_value}")
        return unassigned_input, non_controlling_value
 
    return None
 
 
 
def backtrace(objective, circuit):
    """
    Backtraces through the circuit to determine which PI should be set and to what value.
    Considers paths with inverting gates and adjusts values accordingly.
   
    Parameters:
    - objective: A tuple (net, desired_value) indicating the objective.
    - circuit: The circuit object containing gates and PI information.
 
    Returns:
    - A tuple (pi, value) representing the primary input to be set and the value to assign.
    """
    net, desired_value = objective
    inverting_count = 0  # Counter for the number of inverting gates encountered.
 
    # Continue backtracing until we reach a primary input (PI).
    while net not in circuit.pis:
        # Find the gate whose output is 'net'.
        driving_gate = next(g for g in circuit.gates if g['output'] == net)
       
        # Check if the gate is inverting.
        if driving_gate['type'] in ['NOT', 'NOR', 'NAND']:
            inverting_count += 1
       
        # Select an unassigned input of the driving gate to continue backtracing.
        new_net = select_unassigned_input(driving_gate, circuit)
       
        print(f"Backtrace through gate {driving_gate['name']} ({driving_gate['type']}), inverting count: {inverting_count}")
        net = new_net
 
    # Adjust the desired value based on the number of inverting gates encountered.
    if inverting_count % 2 == 1:
        # Odd number of inverting gates: flip the desired value.
        desired_value = '0' if desired_value == '1' else '1'
        print(f"Inverting path detected (odd count), assigning opposite value as objective: {desired_value}")
    else:
        print(f"Non-inverting path or even inverting gates, assigning same value as objective: {desired_value}")
 
    print(f"Backtrace reached PI: {net} with desired value {desired_value}")
    return net, desired_value
 
def select_unassigned_primary_input(circuit):
    """
    Selects an unassigned primary input (PI) to assist with fault propagation.
   
    Parameters:
    - circuit: The Circuit object representing the digital circuit.
   
    Returns:
    - The name of an unassigned PI, or None if all PIs are assigned.
    """
    for pi in circuit.pis:
        if circuit.get_net_value(pi) == 'x':
            return pi
    return None
 
 
def is_d_or_d_bar_at_po(circuit):
    return any(value in ['D', 'D_bar'] for value in circuit.get_outputs().values())
 
 
def podem(fault, circuit):
    print(f"Starting PODEM with fault: {fault}")
    inject_fault(circuit, fault)
    decision_stack = []  # Keep track of decisions for backtracking.
 
   
    while True:
        # Step 1: Set the next objective for either fault sensitization or propagation.
        # objective = set_objective(fault, circuit)
        print(f"Objective: {objective}")
 
        if objective is None:
            print("No more objectives can be set. No test exists.")
            return None  # No test exists if no valid objective is found.
 
        objective_net, desired_value = objective
        current_value = circuit.get_net_value(objective_net)
 
        print(f"current_value is {current_value}")
        print(f"desired_value is {desired_value}")
        if (current_value == '0' and desired_value == '1') or (current_value == '1' and desired_value == '0'):
            #print(f"Objective net {objective_net} has value {current_value}, which is inverted from desired {desired_value}.")
            # Invert the last decision.
            if decision_stack:
                pi, last_value, original_value = decision_stack.pop()
                new_value = '0' if last_value == '1' else '1'
                print(f"Inverting last decision for PI {pi}: trying {new_value} instead of {last_value}.")
                circuit.set_net_value(pi, new_value)
                decision_stack.append((pi, new_value, original_value))  # Update stack with new decision.
 
                # Re-run forward implication with the inverted decision.
                forward_implication(circuit)
                print("Circuit state after inverting decision and forward implication:")
                circuit.print_state()
                continue  # Re-evaluate with this new change.
        # Assume current_value, desired_value, fault_net, and circuit are defined.
        if current_value == desired_value:
            if desired_value == '0':
                circuit.set_net_value(objective_net, 'D_bar')
                print(f"Assigned 'D_bar' to fault net {objective_net} because desired value is '0'.")
                forward_implication(circuit)
                circuit.print_state()
                forward_implication_df(objective)
                circuit.print_state()
                forward_implication_d_frontier(circuit, decision_stack)
                #forward_implication_d_frontier(circuit,decision_stack)
            else:  # desired_value is '1'
                circuit.set_net_value(objective_net, 'D')
                print(f"Assigned 'D' to fault net {objective_net} because desired value is '1'.")
                forward_implication(circuit)
                circuit.print_state()
                forward_implication_df(objective)
                circuit.print_state()
                forward_implication_d_frontier(circuit, decision_stack)
                #forward_implication_d_frontier(circuit,decision_stack)
 
                # Step 6: Check if the fault effect is observable at a primary output.
        #shruti
        if is_d_or_d_bar_at_po(circuit):
            if(objective_net==pi):
                if desired_value == '0':
                    circuit.set_net_value(objective_net, '0')
                    print(f"Assigned 'D_bar' to fault net {objective_net} because desired value is '0'.")
                   
                #forward_implication_d_frontier(circuit,decision_stack)
                else:  # desired_value is '1'
                    circuit.set_net_value(objective_net, '1')
                    print(f"Assigned 'D' to fault net {objective_net} because desired value is '1'.")
                   
            print("Fault effect detected at primary output. Test pattern found:")
            print(f"{circuit.get_pi_values()}")
            return circuit.get_pi_values()  # A valid test pattern has been generated.
       
        # Step 2: Backtrace to find the PI assignment needed for the objective.
        pi, value = backtrace(objective, circuit)
        print(f"Backtrace result: PI = {pi}, Value = {value}")
 
        # Push the decision onto the stack for potential backtracking.
        decision_stack.append((pi, value, circuit.get_net_value(pi)))
        print(f"Decision stack after push: {decision_stack}")
 
        # Step 3: Assign the PI value in the circuit.
        circuit.set_net_value(pi, value)
        print(f"Assigned {pi} = {value}")
 
        # Step 4: Perform forward implication to update the circuit state.
        forward_implication(circuit)
        print("Circuit state after forward implication:")
        print(f"current_value is {circuit.get_net_value(objective_net)}")
        print(f"desired_value is {desired_value}")
        circuit.print_state()
 
        current_value = circuit.get_net_value(objective_net)
 
        #ADDED
        # if current_value == desired_value:
        #     if desired_value == '0':
        #         circuit.set_net_value(objective_net, 'D_bar')
        #         print(f"Assigned 'D_bar' to fault net {objective_net} because desired value is '0'.")
        #         forward_implication(circuit)
        #         circuit.print_state()
        #         forward_implication_df(objective)
        #         circuit.print_state()
        #         forward_implication_d_frontier(circuit, decision_stack)
        #         #forward_implication_d_frontier(circuit,decision_stack)
        #     else:  # desired_value is '1'
        #         circuit.set_net_value(objective_net, 'D')
        #         print(f"Assigned 'D' to fault net {objective_net} because desired value is '1'.")
        #         forward_implication(circuit)
        #         circuit.print_state()
        #         forward_implication_df(objective)
        #         circuit.print_state()
        #         forward_implication_d_frontier(circuit, decision_stack)
 
        # Step 5: Check if the value of the objective net is inverted after forward simulation.
        print(f"checking at PO {is_d_or_d_bar_at_po(circuit)}")
 
        # Step 7: If no further progress can be made, attempt to backtrack.
        print("Backtracking since objective not satisfied.")
        if not backtrack(circuit, decision_stack):
            print("No more backtracking options available. No test exists.")
            return None  # If no more backtracking options are available, no test exists.
 
 
def backtrack(circuit, decision_stack):
    """
    Backtracks to the previous decision and tries an alternative assignment.
    Focuses on choosing the next input from the same gate first.
 
    Parameters:
    - circuit: The Circuit object representing the digital circuit.
    - decision_stack: A stack containing tuples of (PI, last_value, original_value).
 
    Returns:
    - True if backtracking is possible, False otherwise.
    """
    print("Starting backtracking...")
 
    while decision_stack:
        # Pop the last decision from the stack.
        pi, last_value, original_value = decision_stack.pop()
        print(f"Backtracking: Popped decision for PI = {pi}, Last Value = {last_value}, Original Value = {original_value}")
 
        # Find the gate that has `pi` as an input.
        driving_gate = next((gate for gate in circuit.gates if pi in gate['inputs']), None)
 
        if driving_gate:
            # Look for another input from the same gate that hasn't been tried yet.
            for input_net in driving_gate['inputs']:
                if input_net != pi and circuit.get_net_value(input_net) == 'x':
                    print(f"Assigning next input {input_net} from the same gate {driving_gate['name']} to '{last_value}'.")
                    decision_stack.append((input_net, last_value, circuit.get_net_value(input_net)))
                    circuit.set_net_value(input_net, last_value)
                    forward_implication(circuit)
                    print("Circuit state after trying next input during backtracking:")
                    circuit.print_state()
                    return True
 
        # If no other inputs are available from the same gate, toggle the current PI's value.
        new_value = '0' if last_value == '1' else '1'
        if new_value != original_value:
            print(f"Inverting last decision for PI {pi}: trying {new_value} instead of {last_value}.")
            decision_stack.append((pi, new_value, original_value))
            circuit.set_net_value(pi, new_value)
            forward_implication(circuit)
            print("Circuit state after toggling during backtracking:")
            circuit.print_state()
            return True
 
        # If both values have been tried, reset the PI to 'x' and continue backtracking.
        circuit.set_net_value(pi, 'x')
        print(f"Resetting PI {pi} to 'x' and continuing backtracking.")
 
    print("No more backtracking options available in the decision stack.")
    return False  # No more backtracking options are available.
 
def forward_implication_d_frontier(circuit, decision_stack):
    """
    Performs forward implication only for gates in the D-frontier.
    A gate is in the D-frontier if it has 'D' or 'D_bar' on its inputs.
    If propagation stalls, backtrack and assign or toggle unassigned primary inputs to facilitate propagation.
   
    Parameters:
    - circuit: The Circuit object representing the digital circuit.
    - decision_stack: A stack used to keep track of decisions for potential backtracking.
    """
    print("Performing forward implication for D-frontier gates...")
 
    stable = False
    while not stable:
        stable = True
 
        # for gate in circuit.gates:
        #     input_values = [circuit.get_net_value(net) for net in gate['inputs']]
        #     output_value = circuit.get_net_value(gate['output'])
 
        #     # A gate is in the D-frontier if it has 'D' or 'D_bar' on its inputs.
        #     if 'D' in input_values or 'D_bar' not in input_values:
        #         # Evaluate the gate based on its type and inputs.
        #         print(f"inputs: {input_values}")
        #         print(f"outputs {output_value}")
        #         new_output_value = evaluate_gate(gate['type'], input_values)
               
        #         # If the new output value is different from the current value, update the circuit.
        #         if new_output_value != output_value:
        #             circuit.set_net_value(gate['output'], new_output_value)
        #             print(f"Updated output of gate {gate['name']} to {new_output_value} based on D-frontier.")
        #             stable = False  # Continue until no further changes.
 
        # Iterate over all gates to find those in the D-frontier.
        for gate in circuit.gates:
            input_values = [circuit.get_net_value(net) for net in gate['inputs']]
            output_value = circuit.get_net_value(gate['output'])
 
            # A gate is in the D-frontier if it has 'D' or 'D_bar' on its inputs.
            if 'D' in input_values or 'D_bar' in input_values:
                # Evaluate the gate based on its type and inputs.
                print(f"inputs: {input_values}")
                print(f"outputs {output_value}")
                new_output_value = evaluate_gate(gate['type'], input_values)
               
                # If the new output value is different from the current value, update the circuit.
                if new_output_value != output_value:
                    circuit.set_net_value(gate['output'], new_output_value)
                    print(f"Updated output of gate {gate['name']} to {new_output_value} based on D-frontier.")
                    stable = False  # Continue until no further changes.
   
    # Check if 'D' or 'D_bar' has reached a primary output.
    if not is_d_or_d_bar_at_po(circuit):
        print("D or D_bar has not reached any primary output. Initiating backtracking...")
       
        # Select a new unassigned primary input to facilitate further propagation.
        unassigned_pi = select_unassigned_primary_input(circuit)
       
        if unassigned_pi:
            # Try assigning '1' first.
            initial_value = '1'
            print(f"Trying initial assignment for PI {unassigned_pi} = {initial_value}.")
            decision_stack.append((unassigned_pi, initial_value, circuit.get_net_value(unassigned_pi)))
            circuit.set_net_value(unassigned_pi, initial_value)
            print(f"decision stack before fi: {decision_stack}")
            forward_implication(circuit)
            circuit.print_state()
            forward_implication_df(objective)
            circuit.print_state()
            forward_implication_d_frontier(circuit, decision_stack)
            circuit.print_state()
 
            # If the forward implication did not succeed, try toggling the value.
            if not is_d_or_d_bar_at_po(circuit):
                print(f"Initial assignment for PI {unassigned_pi} did not work. Trying toggling...")
                decision_stack.pop()  # Remove the last decision since it didn't work.
                toggled_value = '0'
                decision_stack.append((unassigned_pi, toggled_value, circuit.get_net_value(unassigned_pi)))
                circuit.set_net_value(unassigned_pi, toggled_value)
                forward_implication(circuit)
                circuit.print_state()
                forward_implication_df(objective)
                circuit.print_state()
                forward_implication_d_frontier(circuit, decision_stack)
 
                # Check again if the toggled value worked.
                if not is_d_or_d_bar_at_po(circuit):
                    print(f"Toggled assignment for PI {unassigned_pi} also did not work. No more assignments possible.")
                    decision_stack.pop()  # Remove the last failed attempt.
                    circuit.set_net_value(unassigned_pi, 'x')  # Reset the PI to unknown.
        else:
            print("No more unassigned primary inputs to adjust for propagation.")
   
    print("D-frontier forward implication complete.")
 
def forward_implication_df(objective):
    objective_net, desired_value = objective
    if(desired_value):
        circuit.set_net_value(objective_net, 'D')
        print("state after fi df")
        circuit.print_state()
    else:
        circuit.set_net_value(objective_net, 'D_bar')
        print("state after fi df")
        circuit.print_state()
 
 
# Define the circuit based on the given format.
'''gates = [
     {'type': 'XOR', 'name': '_0_', 'inputs': ['A', 'B'], 'output': 'S1', 'level': 1},
     {'type': 'XOR', 'name': '_1_', 'inputs': ['S1', 'Cin'], 'output': 'Sum', 'level': 2},
     {'type': 'AND', 'name': '_2_', 'inputs': ['A', 'B'], 'output': 'C1', 'level': 1},
     {'type': 'AND', 'name': '_3_', 'inputs': ['S1', 'Cin'], 'output': 'C2', 'level': 2},
     {'type': 'OR', 'name': '_4_', 'inputs': ['C1', 'C2'], 'output': 'Cout', 'level': 3},
 ]
primary_inputs = {'A', 'B', 'Cin'}
primary_outputs = {'Sum', 'Cout'}
 '''
# gates = [
#     {'type': 'OR', 'name': 'G1', 'inputs': ['A', 'B'], 'output': 'a1', 'level': 1},
#     {'type': 'AND', 'name': 'G2', 'inputs': ['a1', 'a2'], 'output': 'o1', 'level': 2},
#      {'type': 'AND', 'name': 'G3', 'inputs': ['B', 'C'], 'output': 'a2', 'level': 1},
#      {'type': 'OR', 'name': 'G4', 'inputs': ['A', 'C'], 'output': 'a4', 'level': 1},
#     {'type': 'NOT', 'name': 'G5', 'inputs': ['a2'], 'output': 'a3', 'level': 2},
#     {'type': 'AND', 'name': 'G6', 'inputs': ['a3', 'a4'], 'output': 'o2', 'level': 3},
# ]
 
# primary_inputs = {'A', 'B','C'}
# primary_outputs = {'o1','o2'}

#FF multiple fanouts
# gates = [
#     {'type': 'OR', 'name': 'G1', 'inputs': ['A', 'a5'], 'output': 'a3', 'level': 1},
#     {'type': 'NOT', 'name': 'G2', 'inputs': ['A'], 'output': 'a2', 'level': 1},
#      {'type': 'AND', 'name': 'G3', 'inputs': ['a4', 'a5'], 'output': 'a8', 'level': 1},
#      {'type': 'NOT', 'name': 'G4', 'inputs': ['a8'], 'output': 'a6', 'level': 1},
#     {'type': 'OR', 'name': 'G5', 'inputs': ['a2','a4'], 'output': 'a9', 'level': 2},
#     {'type': 'OR', 'name': 'G6', 'inputs': ['a9', 'a7'], 'output': 'Z', 'level': 3},
# ]
 
# primary_inputs = {'B', 'A','a4','a5','a7'}
# primary_outputs = {'Z','a3','a6'}

gates = [
    {'type': 'OR', 'name': 'G1', 'inputs': ['A', 'a5'], 'output': 'a3', 'level': 1},
    {'type': 'NOT', 'name': 'G2', 'inputs': ['A'], 'output': 'a2', 'level': 1},
     {'type': 'AND', 'name': 'G3', 'inputs': ['a4', 'a5'], 'output': 'a8', 'level': 1},
     {'type': 'NOT', 'name': 'G4', 'inputs': ['a8'], 'output': 'a6', 'level': 1},
    {'type': 'OR', 'name': 'G6', 'inputs': ['a2', 'a7'], 'output': 'Z', 'level': 3},
]
 
primary_inputs = {'B', 'A','a4','a5','a7'}
primary_outputs = {'Z','a3','a6'}
 
 

fault = ('a5', '0')

value_a6 = 'x'
value_a3 = 'x'
value_z = 'x'
value_B = 'x'

# Printing the multiplication table of 2
for i in range(1, 3):
    print("RUNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN")
    circuit = Circuit(gates, primary_inputs, primary_outputs)
    objective = set_objective(fault, circuit)
    circuit.set_net_value('a4', value_a3)
    circuit.set_net_value('a7', value_a6)
    circuit.set_net_value('a5', value_B)
    test = podem(fault, circuit)
    if test:
        print(f"Test generated: {test}")
    else:   
        print("No test exists.")
    test1 = test
    circuit.print_state()
    circuit.store_primary_outputs()
    temp_po = circuit.get_stored_outputs()
    print(f"temp pos are {temp_po}")
    value_a6 = temp_po['a6'] 
    value_a3 = temp_po['a3']
    value_z = temp_po['Z']
    value_B = circuit.get_net_value('B')
    print(f"value of a6 is {value_a6}")
    if(value_z == 'D' or value_z == 'D_bar'):
        print("BREAKKKKKKKKKKKK")
        break

print(test1)
print(test)
print(f"current Z is {circuit.get_net_value('Z')}")
    # if test:
    #     print(f"Test generated: {test}")
    # else:   
    #     print("No test exists.")

# fault = ('A', '1')
# objective = set_objective(fault, circuit)
# test = podem(fault, circuit)
 
# if test:
#     print(f"Test generated: {test}")
# else:
#     print("No test exists.")
 
 
'''faults = [
    # ('Cout', '0'),
    # ('Cout', '1'),
    # ('C2', '0'),
    # ('C2', '1'),
    # ('Sum', '0'),
    # ('Sum', '1'),
    # ('S1', '0'),
    # ('S1', '1'),
    # ('C1', '0'),
    # ('C1', '1')
    ('G5O', '0'),
    ('G5O', '1'),
    ('G4O', '0'),
    # ('G40', '1'),
    # ('G3O', '0'),
    ('G3O', '1'),
    # ('G2O', '0'),
    # ('G2O', '1'),
    # ('G1O', '0'),
    ('G1O', '1')
    # Add more faults as needed.
]
 
# Iterate over each fault in the list.
for fault in faults:
    fault_net, stuck_value = fault
    print(f"\nChecking fault: {fault_net} stuck-at-{stuck_value}")
 
    # Create a new instance of the circuit for each fault (assuming a function to create/reset the circuit).
    circuit = Circuit(gates, primary_inputs, primary_outputs)  # This function should initialize or reset the circuit.
 
    # Run PODEM for the current fault.
    test_pattern = podem(fault, circuit)
 
    # Print the result for the current fault.
    if test_pattern:
        print(f"Test pattern for fault {fault_net} stuck-at-{stuck_value}: {test_pattern}")
    else:
        print(f"No test exists for fault {fault_net} stuck-at-{stuck_value}.")
 '''